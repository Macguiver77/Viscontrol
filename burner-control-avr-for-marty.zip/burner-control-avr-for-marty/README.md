# Burner Control AVR

Arduino UNO project implementing a burner control system state machine.

See the [burner-control-avr/README.md](burner-control-avr/README.md) for detailed instructions.
